@extends('layout.main')
@section('title', 'Tentang')
@section('2', 'active')
@section('content')
    
@endsection
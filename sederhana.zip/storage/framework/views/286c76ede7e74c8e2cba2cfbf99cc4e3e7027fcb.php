<?php $__env->startSection('title', 'Belanja Slurr...!'); ?>
<?php $__env->startSection('3', 'active'); ?>
<?php $__env->startSection('hidden', 'd-none d-md-block'); ?>
<?php $__env->startSection('result'); ?>
<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-3 mt-1 mb-2 col-6">
    <a href="<?php echo e(url('belanja/detail').'/'.$brg['kode_barang']); ?>" style="text-decoration:none; height: 100px;">
        <div class="card border-info">
            <img src="<?php echo e(url('img/barang').'/'.$brg['gambar']); ?>" class="card-img-top" style="width: 100%; height: 180px">
            <div class="card-body bg-info">
                <span class="text-white"><?php echo e($brg['nama']); ?></span>
            </div>
        </div>
    </a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.belanja', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jangbe\sederhana\resources\views/belanja/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('1', 'active'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8 col-12">
    <div class="list-group">
        <a href="#" class="list-group-item list-group-item-action active text-center">
            Pesanan
        </a>
        <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($cart->kode_pesan == 1): ?>
            <a href="<?php echo e(url('admin/keranjang').'/'.$cart->kode_pembeli); ?>" class="list-group-item list-group-item-action list-group-item-warning text-center d-flex justify-content-between align-items-center">
                <?php echo e($cart->nama); ?>

                <span>Rp. <?php echo e(number_format($cart->total_harga)); ?></span>
            </a>
        <?php elseif($cart->kode_pesan == 2): ?>
            <a href="<?php echo e(url('admin/keranjang').'/'.$cart->kode_pembeli); ?>" class="list-group-item list-group-item-action list-group-item-info text-center d-flex justify-content-between align-items-center">
                <?php echo e($cart->nama); ?>

                <span>Rp. <?php echo e(number_format($cart->total_harga)); ?></span>
            </a>
        <?php elseif($cart->kode_pesan == 3): ?>
            <a href="<?php echo e(url('admin/keranjang').'/'.$cart->kode_pembeli); ?>" class="list-group-item list-group-item-action list-group-item-primary text-center d-flex justify-content-between align-items-center">
                <?php echo e($cart->nama); ?>

                <span>Rp. <?php echo e(number_format($cart->total_harga)); ?></span>
            </a>
        <?php elseif($cart->kode_pesan == 4): ?>
            <a href="<?php echo e(url('admin/keranjang').'/'.$cart->kode_pembeli); ?>" class="list-group-item list-group-item-action list-group-item-success text-center d-flex justify-content-between align-items-center">
                <?php echo e($cart->nama); ?>

                <span>Rp. <?php echo e(number_format($cart->total_harga)); ?></span>
            </a>
        <?php else: ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-4">

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jangbe\sederhana\resources\views/admin/index.blade.php ENDPATH**/ ?>
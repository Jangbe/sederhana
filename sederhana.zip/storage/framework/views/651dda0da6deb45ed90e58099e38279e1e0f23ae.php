<?php $__env->startSection('link', 'register'); ?>
<?php $__env->startSection('title', 'Daftar'); ?>
<?php $__env->startSection('content'); ?>

<div class="wrap-input100 validate-input m-b-16" data-validate = "Nama Lengkap harus di isi">
    <input class="input100" type="text" name="name" placeholder="Nama Lengkap">
    <span class="focus-input100"></span>
    <span class="symbol-input100">
        <span class="lnr lnr-user"></span>
    </span>
</div>

<div class="wrap-input100 validate-input m-b-16" data-validate = "Email harus di isi: ex@abc.xyz">
    <input class="input100" type="text" name="email" placeholder="Email">
    <span class="focus-input100"></span>
    <span class="symbol-input100">
        <span class="lnr lnr-envelope"></span>
    </span>
</div>

<div class="wrap-input100 validate-input m-b-16" data-validate = "No Telepon harus di isi">
    <input class="input100" type="text" name="telepon" placeholder="Nomer Telepon">
    <span class="focus-input100"></span>
    <span class="symbol-input100">
        <span class="lnr lnr-phone"></span>
    </span>
</div>

<div class="wrap-input100 validate-input m-b-16" data-validate = "Password harus di isi">
    <input class="input100" type="password" name="pass" placeholder="Password">
    <span class="focus-input100"></span>
    <span class="symbol-input100">
        <span class="lnr lnr-lock"></span>
    </span>
</div>

<div class="wrap-input100 validate-input m-b-16" data-validate = "Konfirmasi Password harus di isi">
    <input class="input100" type="password" name="confirm" placeholder="Password">
    <span class="focus-input100"></span>
    <span class="symbol-input100">
        <span class="lnr lnr-lock"></span>
    </span>
</div>



<div class="container-login100-form-btn p-t-25">
    <button class="login100-form-btn" type="submit">
        Daftar
    </button>
</div>

<div class="text-center w-full p-t-50">
    <span class="txt1">
        Sudah punya akun?
    </span>

    <a class="txt1 bo1 hov1" href="<?php echo e(url('/login')); ?>">
        Silahkan masuk						
    </a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jangbe\sederhana\resources\views/auth/register.blade.php ENDPATH**/ ?>
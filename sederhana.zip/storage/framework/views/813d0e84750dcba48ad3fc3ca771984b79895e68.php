    
    <?php $__env->startSection('1', 'active'); ?>
    <?php $__env->startSection('content'); ?>
    <div class="col-12 col-md-7">
        <?php if($data): ?>
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Detail Pembeli</h5>
                <table cellpadding="5" class="col-12">
                    <tr>
                        <td><b>Nama Pembeli</b></td>
                        <td>:</td>
                        <td><?php echo e($data->nama); ?></td>
                    </tr>
                    <tr>
                        <td><b>Email Pembeli</b></td>
                        <td>:</td>
                        <td><?php echo e($data->email); ?></td>
                    </tr>
                    <tr>
                        <td><b>Nomer WA Pembeli</b></td>
                        <td>:</td>
                        <td><?php echo e($data->telepon); ?></td>
                    </tr>
                    <tr>
                        <td><b>Alamat Pembeli</b></td>
                        <td>:</td>
                        <td><?php echo e(str_replace('-', ' - ', $data->alamat)); ?></td>
                    </tr>
                    <tr>
                        <td><b>Catatan Pembeli</b></td>
                        <td>:</td>
                        <td><?php echo e($data->catatan); ?></td>
                    </tr>
                </table>
            </div>
            <?php
                $total = 0;
            ?>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total += $brg->jml_harga;
                ?>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-7">
                            <b><?php echo e($brg->jml_beli); ?></b> <?php echo e($brg->nama); ?> 
                        </div>
                        <div class="col-5 text-right">
                            <?php echo e(number_format($brg->jml_harga)); ?>

                        </div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item text-right">Rp. <?php echo e(number_format($total)); ?> </li>
            </ul>
            <div class="card-body">
                <form action="<?php echo e(url('')); ?>" method="post">
                    <label for="pesan">Status:</label>
                    <select name="pesan" id="pesan" class="custom-select">
                        <?php for($i = 0; $i <= 4; $i++): ?>
                        <?php if($data->kode_pesan == ($i + 1)): ?>
                        <option value="" selected><?php echo e($pesan[$i]->detail_pesan); ?> </option>
                        <?php else: ?>
                        <option value=""><?php echo e($pesan[$i]->detail_pesan); ?> </option>
                        <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                    <button type="submit" class="btn col-12 btn-success mt-3">Update keranjang</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jangbe\sederhana\resources\views/admin/detail.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sederhana | <?php echo $__env->yieldContent('title'); ?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="<?php echo e(url('images/icons/favicon.ico"')); ?>"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('vendor/bootstrap/css/bootstrap.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('fonts/Linearicons-Free-v1.0.0/icon-font.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('vendor/animate/animate.css')); ?>">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('vendor/css-hamburgers/hamburgers.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('vendor/select2/select2.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/util.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/main.css')); ?>">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-50 p-r-50 p-t-30 p-b-30">
				<form class="login100-form validate-form" method="POST" action="/<?php echo $__env->yieldContent('link'); ?>">
					<?php echo csrf_field(); ?>
					<span class="login100-form-title p-b-30">
						<?php echo $__env->yieldContent('title'); ?>
					</span>

					<?php echo $__env->yieldContent('content'); ?>
				</form>
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="<?php echo e(url('vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(url('vendor/bootstrap/js/popper.js')); ?>"></script>
	<script src="<?php echo e(url('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(url('vendor/select2/select2.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(url('js/main.js')); ?>"></script>

</body>
</html><?php /**PATH D:\jangbe\sederhana\resources\views/layout/auth.blade.php ENDPATH**/ ?>
<?php $__env->startSection('2', 'active'); ?>
<?php $__env->startSection('p-1', 'active'); ?>
<?php $__env->startSection('title', 'Tambah Produk'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-4 mb-3">
        <img src="<?php echo e(url('img/barang/default.jpg')); ?>" class="img-thumbnail d-block w-100">
    </div>
    <div class="col-md-8">
        <form action="<?php echo e(url('produk/add')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-5 col-md-3 col-form-label" for="nama">Nama Barang</label>
                <div class="input-group col-7 col-md-9">
                    <input type="text" class="form-control" name="nama" placeholder="Nama barang.." id="nama">
                </div>
                <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                    <span class="text-danger ml-2">Nama barang harus di isi.</span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group row">
                <label class="col-5 col-md-3 col-form-label" for="kode">Stok Barang</label>
                <div class="input-group col-7 col-md-9">
                    <input type="number" class="form-control" min="0" name="stok" placeholder="Stok barang.." id="kode">
                </div>
                <?php if ($errors->has('stok')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stok'); ?>
                    <span class="text-danger ml-2">Stok barang harus di isi.</span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group row">
                <label class="col-5 col-md-3 col-form-label" for="berat">Berat Barang</label>
                <div class="input-group col-7 col-md-9">
                    <input type="text" class="form-control" name="berat" placeholder="Berat barang.." id="berat">
                </div>
                <?php if ($errors->has('stok')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stok'); ?>
                    <span class="text-danger ml-2">Berat barang harus di isi.</span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group row">
                <label class="col-5 col-md-3 col-form-label" for="harga">Harga Barang</label>
                <div class="input-group col-7 col-md-9">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Rp</span>
                    </div>
                    <input type="number" class="form-control" name="harga" placeholder="Harga barang.." id="harga">
                </div>
                <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
                    <span class="text-danger ml-2">Harga barang harus di isi.</span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group row">
                <label class="col-5 col-md-3 col-form-label" for="gambar">Gambar Barang</label>
                <div class="input-group col-7 col-md-9">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="gambar" name="gambar">
                        <label class="custom-file-label" for="gambar">Pilih gambar..</label>
                    </div>
                </div>
                <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?>
                    <span class="text-danger ml-2">Gambar barang harus di pilih.</span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group row">
                <label class="col-5 col-md-3 col-form-label" for="kategori">Kategori Barang</label>
                <div class="input-group col-7 col-md-9">
                    <select name="kategori" class="custom-select" id="kategori">
                        <option value="Roko">Roko</option>
                        <option value="Sabun">Sabun</option>
                        <option value="Makanan">Makanan</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <button class="btn btn-primary col-12">Tambah Barang</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jangbe\sederhana\resources\views/admin/produk.blade.php ENDPATH**/ ?>
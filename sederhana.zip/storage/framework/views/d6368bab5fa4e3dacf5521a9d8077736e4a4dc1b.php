<?php $__env->startSection('title', 'Tentang'); ?>
<?php $__env->startSection('2', 'active'); ?>
<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jangbe\sederhana\resources\views/about.blade.php ENDPATH**/ ?>
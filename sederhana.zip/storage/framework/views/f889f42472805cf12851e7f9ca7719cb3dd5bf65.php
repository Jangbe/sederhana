<?php $__env->startSection('title', 'Edit Produk'); ?>
<?php $__env->startSection('5', 'active'); ?>
<?php $__env->startSection('p-2', 'active'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-12">
    <form action="<?php echo e(url('produk/cari')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <div class="input-group">
            <input type="text" class="form-control" name="cari" autocomplete="off" placeholder="Cari barang...">
            <div class="input-group-append">
                <button class="btn btn-secondary"  type="submit">Cari</button>
            </div>
        </div>
    </div>
    </form>
</div>
<div class="col-12">
    <table class="table table-hover">
        <thead class="bg-primary text-light text-center">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Gambar <span class="d-none d-md-inline">Produk</span></th>
                <th scope="col">Nama <span class="d-none d-md-inline">Produk</span></th>
                <th scope="col">Opsi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row" class="text-center"><?php echo e($loop->iteration); ?></th>
                <td><img src="<?php echo e(url('img/barang').'/'.$dta->gambar); ?>" class="img-thumbnail" style="width:60px;height:60px;"></td>
                <td><?php echo e($dta->nama); ?></td>
                <td class="text-right">
                    <a href="<?php echo e(url('produk/edit').'/'.$dta->kode_barang); ?>" class="btn btn-success"><i class="fas fa-edit"></i><span class="d-none d-md-inline"> Edit</span></a>
                    <a href="<?php echo e(url('produk/delete').'/'.$dta->kode_barang); ?>" class="btn btn-danger"><i class="fas fa-trash"></i><span class="d-none d-md-inline"> Hapus</span></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jangbe\sederhana\resources\views/admin/edit.blade.php ENDPATH**/ ?>